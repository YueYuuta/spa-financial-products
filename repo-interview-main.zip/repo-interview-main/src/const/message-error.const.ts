export const MESSAGE_ERROR = {
    'DuplicateIdentifier': "Duplicate identifier found in the database",
    'NotFound': "Not product found with that identifier",
}